import React from "react";

const LifeguardDashboard = () => {
  return (
    <div>
      <h2>Lifeguard Dashboard</h2>
      <p>Welcome, Lifeguard!</p>
    </div>
  );
};

export default LifeguardDashboard;
