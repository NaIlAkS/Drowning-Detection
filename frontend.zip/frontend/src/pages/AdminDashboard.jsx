import { useState, useEffect } from "react";
import axios from "axios";

const AdminDashboard = () => {
  const [supervisors, setSupervisors] = useState([]);
  const [lifeguards, setLifeguards] = useState([]);

  useEffect(() => {
    fetchSupervisors();
    fetchLifeguards();
  }, []);

  const fetchSupervisors = async () => {
    const res = await axios.get("http://localhost:6000/supervisors", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    setSupervisors(res.data);
  };

  const fetchLifeguards = async () => {
    const res = await axios.get("http://localhost:6000/lifeguards", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    setLifeguards(res.data);
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl">Admin Dashboard</h2>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <h3>Supervisors</h3>
          <ul>{supervisors.map((s) => <li key={s.id}>{s.name} - {s.phone}</li>)}</ul>
        </div>
        <div>
          <h3>Lifeguards</h3>
          <ul>{lifeguards.map((l) => <li key={l.id}>{l.name} - {l.phone}</li>)}</ul>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
