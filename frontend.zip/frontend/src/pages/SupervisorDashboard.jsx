import React from "react";

const SupervisorDashboard = () => {
  return (
    <div>
      <h2>Supervisor Dashboard</h2>
      <p>Welcome, SupervisorDashboard!</p>
    </div>
  );
};

export default SupervisorDashboard;
