import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import AdminDashboard from "./pages/AdminDashboard";
import SupervisorDashboard from "./pages/SupervisorDashboard";
import LifeguardDashboard from "./pages/LifeguardDashboard";
import ProtectedRoute from "./components/ProtectedRoute";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route element={<ProtectedRoute allowedRoles={["admin"]} />}>
          <Route path="/admin" element={<AdminDashboard />} />
        </Route>
        <Route element={<ProtectedRoute allowedRoles={["supervisor"]} />}>
          <Route path="/supervisor" element={<SupervisorDashboard />} />
        </Route>
        <Route element={<ProtectedRoute allowedRoles={["lifeguard"]} />}>
          <Route path="/lifeguard" element={<LifeguardDashboard />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;
