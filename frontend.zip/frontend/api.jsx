import axios from "axios";

const API_BASE_URL = "http://localhost:6000/api"; // Change this to your backend URL

const api = axios.create({
  baseURL: API_BASE_URL,
});

export default api;
